const cors = require("cors");
const express = require ("express");
// conexão com o banco de dados
const db = require ("./model");
const routes = require ("./routes.js");

// Importa os modelos necessários
const {ClientRepository,EstoqueRepository} = require("./model");


// Sincroniza o model com o banco de dados
db.sequelize.sync({
    force: true, // Use force: true apenas durante o desenvolvimento para recriar o banco de dados
  }).then(async () => {
    if(await ClientRepository.count() <5)
    {
        // Adiciona clientes pré-registrados
        await ClientRepository.bulkCreate([
          { nome: "Cliente 1", email: "cliente1@email.com" },
          { nome: "Cliente 2", email: "cliente2@email.com" },
          { nome: "Cliente 3", email: "cliente3@email.com" },
          { nome: "Cliente 4", email: "cliente4@email.com" },
          { nome: "Cliente 5", email: "cliente5@email.com" },
        ]);
    }
  
    if(await EstoqueRepository.count() <10)
    {
        // Adiciona produtos pré-registrados
        await EstoqueRepository.bulkCreate([
            { nome: "Produto 1", quantidade: 5, preco: 50, descricao: "a" },
            { nome: "Produto 2", quantidade: 5, preco: 100, descricao: "b" },
            { nome: "Produto 3", quantidade: 5, preco: 150, descricao: "c" },
            { nome: "Produto 4", quantidade: 10, preco: 200, descricao: "d" },
            { nome: "Produto 5", quantidade: 15, preco: 250 , descricao: "e"},
            { nome: "Produto 6", quantidade: 15, preco: 300 , descricao: "f"},
            { nome: "Produto 7", quantidade: 15, preco: 350 , descricao: "g"},
            { nome: "Produto 8", quantidade: 15, preco: 400 , descricao: "h"},
            { nome: "Produto 9", quantidade: 15, preco: 450 , descricao: "i"},
            { nome: "Produto 10", quantidade: 15, preco: 500 , descricao: "j"},
        ]);
    }
        
        console.info(`Banco de dados preenchido`);   
    });

// instancia o servidor Express
const app = express();

//configura o uso da resposta em formato json
app.use(express.json());

app.use(cors({
    origin: "*"
}));

//configura as rotas
app.use(routes);

// inicializa o express na porta 3000
app.listen(3000, () => console.log("Servidor iniciado em http://127.0.0.1:3000"));

///////////////////////////////////////////////////////////////
