const NotFoundError = require("../error/NotFoundError");
const RequiredParameterError = require("../error/RequiredParameterError");
const {ClientRepository} = require("../model");

class ClienteController{
  async findAll(req, res) {
    const clients = await ClientRepository.findAll();
    res.json(clients);
  }
  async update(req, res) {
    try{
      // Teste de campos Obrigatorios
      if(!req.body.idCliente) throw new RequiredParameterError('idCliente')
      const cliente = await ClientRepository.findOne({
        where:{
          idCliente:req.body.idCliente
        }
      })
      
      if(!cliente) throw new NotFoundError('Cliente')

      await ClientRepository.update({
        "nome":req.body.nome,
	      "email":req.body.email
      },{
        where:{
          idCliente:req.body.idCliente
        }
      })

      const clienteUpdate = await ClientRepository.findOne({
        where:{
          idCliente:req.body.idCliente
        }
      })
      res.json(clienteUpdate);
    }catch(error)
    {
      return res.status(error.status||422 ).json(error)
    }
  }

  async delete(req, res) {
    try{
      // Teste de campos Obrigatorios
      if(!req.params.idCliente) throw new RequiredParameterError('idCliente')
      const cliente = await ClientRepository.findOne({
        where:{
          idCliente:req.params.idCliente
        }
      })
      
      if(!cliente) throw new NotFoundError('Cliente')

      const clienteDeletado = await ClientRepository.destroy({
        where:{
          idCliente:req.params.idCliente
        }
      })

      res.json({message: "Cliente removido com sucesso" });
    }catch(error)
    {
      return res.status(error.status||422 ).json(error)
    }
  }


    async create(req, res) {
      try{
        console.log(req.body)
        // Teste de campos Obrigatorios
        if(!req.body.nome) throw new RequiredParameterError('nome')
        if(!req.body.email) throw new RequiredParameterError('email')

        const clients = await ClientRepository.create({
          "nome":req.body.nome,
          "email":req.body.email
        });
        return res.json(clients);
      }catch(error)
      {
        if(error.name === 'SequelizeUniqueConstraintError')
        {
          return res.status(422).json({
            idClienteError: "ALREADY_EXIST",
            message:  `Já existe cadastro com esse ${error.fields[0]}`
          })
          
        }
        return res.json(error)
      }
    }

}

module.exports  = new ClienteController();