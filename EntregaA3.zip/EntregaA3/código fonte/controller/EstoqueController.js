const NotFoundError = require("../error/NotFoundError");
const RequiredParameterError = require("../error/RequiredParameterError");
const {EstoqueRepository} = require("../model");

class EstoqueController{
  async findAll(req, res) {
    const estoques = await EstoqueRepository.findAll();
    res.json(estoques);
  }
  async update(req, res) {
    try{
      // Teste de campos Obrigatorios
      if(!req.body.idEstoque) throw new RequiredParameterError('idEstoque')
      const estoque = await EstoqueRepository.findOne({
        where:{
          idEstoque:req.body.idEstoque
        }
      })
      
      if(!estoque) throw new NotFoundError('Estoque')

      await EstoqueRepository.update({
        "nome":req.body.nome,
	      "quantidade":req.body.quantidade,
        "preco":req.body.preco,
        "descricao":req.body.descricao
      },{
        where:{
          idEstoque:req.body.idEstoque
        }
      })

      const estoqueUpdate = await EstoqueRepository.findOne({
        where:{
          idEstoque:req.body.idEstoque
        }
      })
      res.json(estoqueUpdate);
    }catch(error)
    {
      return res.status(error.status||422 ).json(error)
    }
  }

  async delete(req, res) {
    try{
      // Teste de campos Obrigatorios
      if(!req.params.idEstoque) throw new RequiredParameterError('idEstoque')
      const estoque = await EstoqueRepository.findOne({
        where:{
          idEstoque:req.params.idEstoque
        }
      })
      
      if(!estoque) throw new NotFoundError('Estoque')

      const estoqueDeletado = await EstoqueRepository.destroy({
        where:{
          idEstoque:req.params.idEstoque
        }
      })

      res.json({message: "Estoque removido com sucesso" });
    }catch(error)
    {
      return res.status(error.status||422 ).json(error)
    }
  }


  async create(req, res) {
    try{
      console.log(req.body)
      // Teste de campos Obrigatorios
      if(!req.body.nome) throw new RequiredParameterError('nome')
      if(!req.body.quantidade) throw new RequiredParameterError('quantidade')
      if(!req.body.preco) throw new RequiredParameterError('preco')
      if(!req.body.descricao) throw new RequiredParameterError('descricao')

      const estoques = await EstoqueRepository.create({
        "nome":req.body.nome,
        "quantidade":req.body.quantidade,
        "preco":req.body.preco,
        "descricao":req.body.descricao
      });
      return res.json(estoques);
    }catch(error)
    {
      if(error.name === 'SequelizeUniqueConstraintError')
      {
        return res.json({
          idError: "ALREADY_EXIST",
          message:  `Já existe cadastro com esse ${error.fields[0]}`
        })
        
      }
      return res.json(error)
    }
  }
}

module.exports = new EstoqueController();