const InsuficientProductError = require("../error/InsuficientProductError");
const NotFoundError = require("../error/NotFoundError");
const RequiredParameterError = require("../error/RequiredParameterError");
const {VendaRepository,EstoqueRepository,ClientRepository} = require("../model");


class VendaController{
  async findAll(req, res) {
    const vendas = await VendaRepository.findAll({
      include: [{
        model: EstoqueRepository,
        as: "Estoque"
      },{
        model: ClientRepository,
        as: "Cliente"
      }]
    });
    res.json(vendas);
  }
  async update(req, res) {
    try{
      // Teste de campos Obrigatorios
      if(!req.body.idVenda) throw new RequiredParameterError('idVenda')
      const venda = await VendaRepository.findOne({
        where:{
          idVenda:req.body.idVenda
        }
      })
      
      if(!venda) throw new NotFoundError('Cliente')

      await VendaRepository.update({
        "nome":req.body.nome,
	      "email":req.body.email
      },{
        where:{
          idVenda:req.body.idVenda
        }
      })

      const vendaUpdate = await VendaRepository.findOne({
        where:{
          idVenda:req.body.idVenda
        }
      })
      res.json(vendaUpdate);
    }catch(error)
    {
      return res.status(error.status||422 ).json(error)
    }
  }

  async delete(req, res) {
    try{
      // Teste de campos Obrigatorios
      if(!req.params.idVenda) throw new RequiredParameterError('idVenda')
      const venda = await VendaRepository.findOne({
        where:{
          idVenda:req.params.idVenda
        }
      })
      
      if(!venda) throw new NotFoundError('Cliente')

      const vendaDeletada = await VendaRepository.destroy({
        where:{
          idVenda:req.params.idVenda
        }
      })

      res.json({message: "Venda removido com sucesso" });
    }catch(error)
    {
      return res.status(error.status||422 ).json(error)
    }
  }


    async create(req, res) {
      try{
        console.log(req.body)
        // Teste de campos Obrigatorios
        if(!req.body.idEstoque) throw new RequiredParameterError('idEstoque')
        if(!req.body.idCliente) throw new RequiredParameterError('idCliente')

        const estoque = await EstoqueRepository.findOne({
          where:{
            idEstoque:req.body.idEstoque
          }
        })
        if(!estoque) throw new NotFoundError('Estoque')
        if(estoque.quantidade <= 0) throw new InsuficientProductError()
        
        await EstoqueRepository.update({
          quantidade: estoque.quantidade - 1
        },{
          where:{
            idEstoque:estoque.idEstoque
          }
        })
        const vendas = await VendaRepository.create({
          "idEstoque":req.body.idEstoque,
          "idCliente":req.body.idCliente,
          "preco":estoque.preco
        });
        return res.json(vendas);
      }catch(error)
      {
        if(error.name === 'SequelizeUniqueConstraintError')
        {
          return res.json({
            idError: "ALREADY_EXIST",
            message:  `Já existe cadastro com esse ${error.fields[0]}`
          })
          
        }
        return res.json(error)
      }
    }

}


module.exports  = new VendaController();