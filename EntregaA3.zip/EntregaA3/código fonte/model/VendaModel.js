// const { Sequelize } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  console.log(sequelize)
  const Venda = sequelize.define("VendaRepository", {
    idVenda: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    idEstoque: {
      type: DataTypes.INTEGER,
      references: {
        model: "estoque", // 'Actors' would also work
        key: 'idEstoque'
      },
      allowNull: false,
    },
    idCliente: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "cliente", // 'Actors' would also work
        key: 'idCliente'
      }
    },
    preco: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
    },
  },{
    tableName: 'venda'
  })
  Venda.associate = (models) => {
    Venda.belongsTo(models.EstoqueRepository, {
      foreignKey: 'idEstoque',
      as: 'Estoque'
    })
    Venda.belongsTo(models.ClientRepository, {
      foreignKey: 'idCliente',
      as: 'Cliente'
    })
  }
  return Venda
 };